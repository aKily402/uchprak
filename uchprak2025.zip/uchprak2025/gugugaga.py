from enum import auto

pip install auto-py-to-exe
