import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pyodbc

class OlympicDbApp:

    def __init__(self, root):
        self.root = root
        self.root.title("Учет призеров Олимпийских игр")
        self.root.geometry("950x680")

        self.conn = None
        self.cursor = None

        self.all_athletes = []
        self.all_games = []
        self.all_sports = []
        self.all_results = []

        self.athletes_dict = {}
        self.games_dict = {}
        self.sports_dict = {}

        self.create_top_panel()

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_athletes = ttk.Frame(self.notebook)
        self.tab_games = ttk.Frame(self.notebook)
        self.tab_sports = ttk.Frame(self.notebook)
        self.tab_results = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_athletes, text="Спортсмены")
        self.notebook.add(self.tab_games, text="Олимпиады")
        self.notebook.add(self.tab_sports, text="Виды спорта")
        self.notebook.add(self.tab_results, text="Результаты")

        self.setup_athletes_tab()
        self.setup_games_tab()
        self.setup_sports_tab()
        self.setup_results_tab()

        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def create_top_panel(self):
        file_frame = tk.Frame(self.root, pady=5)
        file_frame.pack(fill=tk.X)

        self.btn_select_db = tk.Button(
            file_frame, text="Выбрать базу данных Access", command=self.select_database
        )
        self.btn_select_db.pack(side=tk.LEFT, padx=10)

        self.lbl_db_status = tk.Label(
            file_frame, text="База данных не выбрана", fg="red"
        )
        self.lbl_db_status.pack(side=tk.LEFT, padx=10)

        search_frame = tk.LabelFrame(
            self.root, text="Быстрый поиск по таблице", padx=10, pady=5
        )
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        tk.Label(search_frame, text="Введите текст для фильтрации:").pack(
            side=tk.LEFT, padx=5
        )

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self.filter_data)

        self.ent_search = tk.Entry(
            search_frame, textvariable=self.search_var, width=40
        )
        self.ent_search.pack(side=tk.LEFT, padx=5)

        btn_clear_search = tk.Button(
            search_frame, text="Очистить", command=self.clear_search
        )
        btn_clear_search.pack(side=tk.LEFT, padx=5)

    def setup_athletes_tab(self):
        frame = tk.LabelFrame(
            self.tab_athletes, text="Добавить спортсмена", padx=10, pady=5
        )
        frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame, text="ФИО:").grid(row=0, column=0, sticky="e")
        self.ent_a_fio = tk.Entry(frame, width=25)
        self.ent_a_fio.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(frame, text="Пол:").grid(row=0, column=2, sticky="e")
        self.ent_a_gender = tk.Entry(frame, width=10)
        self.ent_a_gender.grid(row=0, column=3, padx=5, pady=2)

        tk.Label(frame, text="Дата рождения:").grid(
            row=1, column=0, sticky="e"
        )
        self.ent_a_birth = tk.Entry(frame, width=25)
        self.ent_a_birth.grid(row=1, column=1, padx=5, pady=2)

        tk.Label(frame, text="Страна:").grid(row=1, column=2, sticky="e")
        self.ent_a_country = tk.Entry(frame, width=15)
        self.ent_a_country.grid(row=1, column=3, padx=5, pady=2)

        tk.Button(frame, text="Сохранить", command=self.add_athlete).grid(
            row=0, column=4, rowspan=2, padx=15
        )

        self.tree_a = ttk.Treeview(
            self.tab_athletes,
            columns=("id", "fio", "gender", "birth", "country"),
            show="headings",
        )
        for col, text in [
            ("id", "Код"),
            ("fio", "ФИО"),
            ("gender", "Пол"),
            ("birth", "Дата рождения"),
            ("country", "Страна"),
        ]:
            self.tree_a.heading(col, text=text)
        self.tree_a.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tk.Button(
            self.tab_athletes,
            text="Удалить выбранного спортсмена",
            command=lambda: self.delete_record(
                "Спортсмены", "Код_спортсмена", self.tree_a, self.load_athletes
            ),
        ).pack(anchor="w", padx=5, pady=5)

    def setup_games_tab(self):
        frame = tk.LabelFrame(
            self.tab_games, text="Добавить Олимпиаду", padx=10, pady=5
        )
        frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame, text="Год:").grid(row=0, column=0, sticky="e")
        self.ent_g_year = tk.Entry(frame, width=10)
        self.ent_g_year.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(frame, text="Сезон:").grid(row=0, column=2, sticky="e")
        self.ent_g_season = tk.Entry(frame, width=15)
        self.ent_g_season.grid(row=0, column=3, padx=5, pady=2)

        tk.Label(frame, text="Город:").grid(row=0, column=4, sticky="e")
        self.ent_g_city = tk.Entry(frame, width=20)
        self.ent_g_city.grid(row=0, column=5, padx=5, pady=2)

        tk.Button(frame, text="Сохранить", command=self.add_game).grid(
            row=0, column=6, padx=15
        )

        self.tree_g = ttk.Treeview(
            self.tab_games,
            columns=("id", "year", "season", "city"),
            show="headings",
        )
        for col, text in [
            ("id", "Код"),
            ("year", "Год"),
            ("season", "Сезон"),
            ("city", "Город проведения"),
        ]:
            self.tree_g.heading(col, text=text)
        self.tree_g.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tk.Button(
            self.tab_games,
            text="Удалить выбранную Олимпиаду",
            command=lambda: self.delete_record(
                "Олимпиады", "Код_олимпиады", self.tree_g, self.load_games
            ),
        ).pack(anchor="w", padx=5, pady=5)

    def setup_sports_tab(self):
        frame = tk.LabelFrame(
            self.tab_sports,
            text="Добавить вид спорта / дисциплину",
            padx=10,
            pady=5,
        )
        frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame, text="Вид спорта:").grid(row=0, column=0, sticky="e")
        self.ent_s_name = tk.Entry(frame, width=25)
        self.ent_s_name.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(frame, text="Дисциплина:").grid(row=0, column=2, sticky="e")
        self.ent_s_disc = tk.Entry(frame, width=30)
        self.ent_s_disc.grid(row=0, column=3, padx=5, pady=2)

        tk.Button(frame, text="Сохранить", command=self.add_sport).grid(
            row=0, column=4, padx=15
        )

        self.tree_s = ttk.Treeview(
            self.tab_sports, columns=("id", "name", "disc"), show="headings"
        )
        for col, text in [
            ("id", "Код"),
            ("name", "Название вида"),
            ("disc", "Дисциплина"),
        ]:
            self.tree_s.heading(col, text=text)
        self.tree_s.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tk.Button(
            self.tab_sports,
            text="Удалить выбранный вид спорта",
            command=lambda: self.delete_record(
                "Виды_спорта", "Код_вида_спорта", self.tree_s, self.load_sports
            ),
        ).pack(anchor="w", padx=5, pady=5)

    def setup_results_tab(self):
        frame = tk.LabelFrame(
            self.tab_results, text="Регистрация олимпийской медали", padx=10, pady=5
        )
        frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame, text="Спортсмен:").grid(row=0, column=0, sticky="e")
        self.cmb_res_athlete = ttk.Combobox(frame, width=30, state="readonly")
        self.cmb_res_athlete.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(frame, text="Олимпиада:").grid(row=0, column=2, sticky="e")
        self.cmb_res_game = ttk.Combobox(frame, width=25, state="readonly")
        self.cmb_res_game.grid(row=0, column=3, padx=5, pady=2)

        tk.Label(frame, text="Дисциплина:").grid(row=1, column=0, sticky="e")
        self.cmb_res_sport = ttk.Combobox(frame, width=30, state="readonly")
        self.cmb_res_sport.grid(row=1, column=1, padx=5, pady=2)

        tk.Label(frame, text="Медаль:").grid(row=1, column=2, sticky="e")
        self.cmb_res_medal = ttk.Combobox(
            frame, values=["Золото", "Серебро", "Бронза"], width=15, state="readonly"
        )
        self.cmb_res_medal.grid(row=1, column=3, padx=5, pady=2)

        tk.Button(frame, text="Добавить результат", command=self.add_result).grid(
            row=0, column=4, rowspan=2, padx=15
        )

        self.tree_r = ttk.Treeview(
            self.tab_results,
            columns=("id", "athlete", "game", "sport", "medal"),
            show="headings",
        )
        for col, text in [
            ("id", "Код"),
            ("athlete", "Спортсмен"),
            ("game", "Олимпиада"),
            ("sport", "Вид спорта / Дисциплина"),
            ("medal", "Медаль"),
        ]:
            self.tree_r.heading(col, text=text)
        self.tree_r.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tk.Button(
            self.tab_results,
            text="Удалить выбранный результат",
            command=lambda: self.delete_record(
                "Результаты", "Код_результата", self.tree_r, self.load_results
            ),
        ).pack(anchor="w", padx=5, pady=5)

    def select_database(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("Access Files", "*.accdb;*.mdb")]
        )
        if not file_path:
            return

        conn_str = (
            r"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ="
            + os.path.abspath(file_path)
            + ";"
        )
        try:
            self.conn = pyodbc.connect(conn_str)
            self.cursor = self.conn.cursor()
            self.lbl_db_status.config(
                text=f"Подключено: {os.path.basename(file_path)}", fg="green"
            )
            self.load_all_data()
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось подключиться к БД:\n{e}")

    def on_tab_changed(self, event):
        self.clear_search()
        if self.notebook.index(self.notebook.select()) == 3:
            self.refresh_comboboxes()

    def load_all_data(self):
        self.load_athletes()
        self.load_games()
        self.load_sports()
        self.load_results()

    def load_athletes(self):
        if not self.cursor:
            return
        self.cursor.execute(
            "SELECT Код_спортсмена, ФИО, Пол, Дата_рождения, Страна FROM Спортсмены"
        )
        self.all_athletes = []
        for r in self.cursor.fetchall():
            birth = r[3].strftime("%Y-%m-%d") if r[3] else ""
            self.all_athletes.append((r[0], r[1], r[2], birth, r[4]))
        self.display_data(self.tree_a, self.all_athletes)

    def load_games(self):
        if not self.cursor:
            return
        self.cursor.execute(
            "SELECT Код_олимпиады, Год, Сезон, Город_проведения FROM Олимпиады"
        )
        self.all_games = [tuple(r) for r in self.cursor.fetchall()]
        self.display_data(self.tree_g, self.all_games)

    def load_sports(self):
        if not self.cursor:
            return
        self.cursor.execute(
            "SELECT Код_вида_спорта, Название_вида, Дисциплина FROM Виды_спорта"
        )
        self.all_sports = [tuple(r) for r in self.cursor.fetchall()]
        self.display_data(self.tree_s, self.all_sports)

    def load_results(self):
        if not self.cursor:
            return
        query = """
            SELECT Результаты.Код_результата, Спортсмены.ФИО, Олимпиады.Город_проведения, Олимпиады.Год, Виды_спорта.Название_вида, Виды_спорта.Дисциплина, Результаты.Медаль
            FROM ((Результаты 
            INNER JOIN Спортсмены ON Результаты.Код_спортсмена = Спортсмены.Код_спортсмена)
            INNER JOIN Олимпиады ON Результаты.Код_олимпиады = Олимпиады.Код_олимпиады)
            INNER JOIN Виды_спорта ON Результаты.Код_вида_спорта = Виды_спорта.Код_вида_спорта
        """
        try:
            self.cursor.execute(query)
            self.all_results = []
            for r in self.cursor.fetchall():
                game_str = f"{r[2]} {r[3]}"
                sport_str = f"{r[4]} ({r[5]})"
                self.all_results.append((r[0], r[1], game_str, sport_str, r[6]))
            self.display_data(self.tree_r, self.all_results)
        except Exception as e:
            print("Ошибка чтения результатов:", e)

    def display_data(self, tree, data_list):
        for item in tree.get_children():
            tree.delete(item)
        for row in data_list:
            tree.insert("", tk.END, values=row)

    def filter_data(self, *args):
        search_text = self.search_var.get().lower().strip()
        current_tab = self.notebook.index(self.notebook.select())

        if current_tab == 0:
            filtered = [
                row
                for row in self.all_athletes
                if any(search_text in str(val).lower() for val in row)
            ]
            self.display_data(self.tree_a, filtered)
        elif current_tab == 1:
            filtered = [
                row
                for row in self.all_games
                if any(search_text in str(val).lower() for val in row)
            ]
            self.display_data(self.tree_g, filtered)
        elif current_tab == 2:
            filtered = [
                row
                for row in self.all_sports
                if any(search_text in str(val).lower() for val in row)
            ]
            self.display_data(self.tree_s, filtered)
        elif current_tab == 3:
            filtered = [
                row
                for row in self.all_results
                if any(search_text in str(val).lower() for val in row)
            ]
            self.display_data(self.tree_r, filtered)

    def clear_search(self):
        self.search_var.set("")

    def refresh_comboboxes(self):
        if not self.cursor:
            return
        self.cursor.execute("SELECT Код_спортсмена, ФИО, Страна FROM Спортсмены")
        self.athletes_dict = {
            f"{r[1]} ({r[2]})": r[0] for r in self.cursor.fetchall()
        }
        self.cmb_res_athlete["values"] = list(self.athletes_dict.keys())

        self.cursor.execute(
            "SELECT Код_олимпиады, Год, Город_проведения FROM Олимпиады"
        )
        self.games_dict = {
            f"{r[2]} {r[1]}": r[0] for r in self.cursor.fetchall()
        }
        self.cmb_res_game["values"] = list(self.games_dict.keys())

        self.cursor.execute(
            "SELECT Код_вида_спорта, Название_вида, Дисциплина FROM Виды_спорта"
        )
        self.sports_dict = {
            f"{r[1]} - {r[2]}": r[0] for r in self.cursor.fetchall()
        }
        self.cmb_res_sport["values"] = list(self.sports_dict.keys())

    def add_athlete(self):
        fio, gen, birth, cntr = (
            self.ent_a_fio.get().strip(),
            self.ent_a_gender.get().strip(),
            self.ent_a_birth.get().strip(),
            self.ent_a_country.get().strip(),
        )
        if not fio or not cntr:
            return messagebox.showwarning("Ошибка", "Заполните ФИО и Страну")
        try:
            self.cursor.execute(
                "INSERT INTO Спортсмены (ФИО, Пол, Дата_рождения, Страна) VALUES (?, ?, ?, ?)",
                (fio, gen, birth if birth else None, cntr),
            )
            self.conn.commit()
            self.load_athletes()
            for e in [
                self.ent_a_fio,
                self.ent_a_gender,
                self.ent_a_birth,
                self.ent_a_country,
            ]:
                e.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def add_game(self):
        year, season, city = (
            self.ent_g_year.get().strip(),
            self.ent_g_season.get().strip(),
            self.ent_g_city.get().strip(),
        )
        if not year or not city:
            return messagebox.showwarning("Ошибка", "Заполните Год и Город")
        try:
            self.cursor.execute(
                "INSERT INTO Олимпиады (Год, Сезон, Город_проведения) VALUES (?, ?, ?)",
                (int(year), season, city),
            )
            self.conn.commit()
            self.load_games()
            for e in [self.ent_g_year, self.ent_g_season, self.ent_g_city]:
                e.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def add_sport(self):
        name, disc = (
            self.ent_s_name.get().strip(),
            self.ent_s_disc.get().strip(),
        )
        if not name or not disc:
            return messagebox.showwarning("Ошибка", "Заполните Вид и Дисциплину")
        try:
            self.cursor.execute(
                "INSERT INTO Виды_спорта (Название_вида, Дисциплина) VALUES (?, ?)",
                (name, disc),
            )
            self.conn.commit()
            self.load_sports()
            for e in [self.ent_s_name, self.ent_s_disc]:
                e.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def add_result(self):
        ath_sel, gam_sel, spo_sel, medal = (
            self.cmb_res_athlete.get(),
            self.cmb_res_game.get(),
            self.cmb_res_sport.get(),
            self.cmb_res_medal.get(),
        )
        if not all([ath_sel, gam_sel, spo_sel, medal]):
            return messagebox.showwarning(
                "Ошибка", "Заполните все выпадающие поля"
            )
        try:
            self.cursor.execute(
                "INSERT INTO Результаты (Код_спортсмена, Код_олимпиады, Код_вида_спорта, Медаль) VALUES (?, ?, ?, ?)",
                (
                    self.athletes_dict[ath_sel],
                    self.games_dict[gam_sel],
                    self.sports_dict[spo_sel],
                    medal,
                ),
            )
            self.conn.commit()
            self.load_results()
            for c in [
                self.cmb_res_athlete,
                self.cmb_res_game,
                self.cmb_res_sport,
                self.cmb_res_medal,
            ]:
                c.set("")
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def delete_record(
        self, table_name, id_column_name, tree_widget, reload_function
    ):
        selected = tree_widget.selection()
        if not selected:
            return messagebox.showwarning("Внимание", "Ничего не выбрано!")
        record_id = tree_widget.item(selected)["values"][0]
        if not messagebox.askyesno(
            "Подтверждение", f"Удалить запись с Кодом {record_id} из {table_name}?"
        ):
            return
        try:
            self.cursor.execute(
                f"DELETE FROM {table_name} WHERE {id_column_name} = ?",
                (record_id,),
            )
            self.conn.commit()
            reload_function()
        except Exception as e:
            messagebox.showerror(
                "Ошибка удаления",
                f"Запись связана с другими таблицами!\n\nДетали: {e}",
            )


if __name__ == "__main__":
    root = tk.Tk()
    app = OlympicDbApp(root)
    root.mainloop()

